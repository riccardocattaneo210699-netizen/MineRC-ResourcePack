#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec2 UV0;

layout(location = 0) out vec2 texCoord0;

void main() {
    vec3 pos = Position;
    float lato = max(abs(pos.x), abs(pos.z));
    if (abs(abs(pos.y) - 100.0) < 0.5) {
        if (pos.y > 0.0 && abs(lato - 30.0) < 0.5) {
            pos.xz *= 4.0;          // sole
        } else if (pos.y < 0.0 && abs(lato - 20.0) < 0.5) {
            pos.xz *= 2.5;          // luna
        }
    }
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
    texCoord0 = UV0;
}
