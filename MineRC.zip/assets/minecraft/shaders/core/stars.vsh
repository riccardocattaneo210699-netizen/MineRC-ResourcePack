#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;

layout(location = 0) out vec3 localPos;
layout(location = 1) out vec2 corner;
layout(location = 2) flat out int kind;
layout(location = 3) flat out float seed;

const vec3 NORMALI[6] = vec3[](vec3(1, 0, 0), vec3(-1, 0, 0), vec3(0, 1, 0), vec3(0, -1, 0), vec3(0, 0, 1), vec3(0, 0, -1));
const vec2 ANGOLI[4] = vec2[](vec2(-1, -1), vec2(-1, 1), vec2(1, 1), vec2(1, -1));

void main() {
    int quad = gl_VertexIndex / 4;
    int v = gl_VertexIndex % 4;
    vec3 pos = Position;
    corner = ANGOLI[v];
    seed = fract(sin(float(quad) * 12.9898) * 43758.5453);
    kind = 0;
    if (quad < 6) {
        vec3 n = NORMALI[quad];
        vec3 u = abs(n.y) > 0.5 ? vec3(1, 0, 0) : vec3(0, 1, 0);
        vec3 w = cross(n, u);
        pos = (n + corner.x * u + corner.y * w) * 100.0;
        kind = 1;
    } else {
        // stella un po' piu' grande per poterla disegnare tonda e morbida
        pos = Position * 1.0;
    }
    localPos = pos;
    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);
}
