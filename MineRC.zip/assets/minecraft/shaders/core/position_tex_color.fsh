#version 330
#extension GL_ARB_separate_shader_objects : require

// MineRC: il cielo "end" diventa lo spazio (generato da resourcepack/cielo.py).
// Se la texture non e' end_sky.png di MineRC (marcatore nel pixel 0,0) si comporta come il vanilla.
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Globals {
    ivec3 CameraBlockPos;
    float GlintAlpha;
    vec3 CameraOffset;
    float GameTime;
    vec2 ScreenSize;
    int MenuBlurRadius;
    int UseRgss;
};

uniform sampler2D Sampler0;

layout(location = 0) in vec2 texCoord0;
layout(location = 1) in vec4 vertexColor;
layout(location = 2) in vec3 skyPos;

layout(location = 0) out vec4 fragColor;

#define PI 3.14159265

const int N_STELLE = 99;
const vec4 STELLE[N_STELLE] = vec4[](
    vec4(-0.45911, 0.88089, -0.11511, 1.80),
    vec4(-0.53592, 0.83273, -0.13910, 2.40),
    vec4(-0.59180, 0.80593, -0.01601, 2.40),
    vec4(-0.54297, 0.83896, 0.03654, 3.30),
    vec4(-0.54431, 0.82865, 0.13068, 1.80),
    vec4(-0.53650, 0.81845, 0.20568, 2.20),
    vec4(-0.58155, 0.75825, 0.29472, 1.90),
    vec4(0.01018, 0.99992, -0.00794, 2.00),
    vec4(-0.00722, 0.99822, 0.05922, 4.40),
    vec4(-0.04394, 0.99036, 0.13133, 4.20),
    vec4(-0.11819, 0.97738, 0.17539, 4.30),
    vec4(-0.10646, 0.96923, 0.22194, 5.00),
    vec4(-0.19971, 0.95014, 0.23949, 3.00),
    vec4(-0.20068, 0.96203, 0.18502, 2.10),
    vec4(0.51238, 0.85851, -0.02058, 2.30),
    vec4(0.54277, 0.83427, -0.09693, 2.20),
    vec4(0.47419, 0.87224, -0.11977, 2.50),
    vec4(0.46199, 0.86811, -0.18152, 2.70),
    vec4(0.38942, 0.89625, -0.21232, 3.40),
    vec4(0.02077, 0.12897, -0.99143, 0.50),
    vec4(0.19521, -0.14263, -0.97033, 0.10),
    vec4(0.15076, 0.11060, -0.98236, 1.60),
    vec4(0.05245, -0.16797, -0.98440, 2.10),
    vec4(0.08363, -0.03385, -0.99592, 1.80),
    vec4(0.10364, -0.02094, -0.99439, 1.70),
    vec4(0.12187, -0.00524, -0.99253, 2.20),
    vec4(0.10681, 0.17244, -0.97921, 3.40),
    vec4(0.45558, 0.71055, 0.53625, 1.25),
    vec4(0.44369, 0.64626, 0.62088, 2.20),
    vec4(0.55007, 0.55876, 0.62065, 2.50),
    vec4(0.31203, 0.70871, 0.63274, 2.90),
    vec4(0.34051, 0.46886, 0.81500, 3.10),
    vec4(0.12497, 0.62633, 0.76947, 0.03),
    vec4(0.15389, 0.61015, 0.77720, 4.30),
    vec4(0.18113, 0.54990, 0.81535, 3.50),
    vec4(0.21427, 0.54009, 0.81387, 3.30),
    vec4(0.18838, 0.60042, 0.77718, 4.30),
    vec4(0.45928, 0.15419, 0.87480, 0.80),
    vec4(0.43972, 0.18412, 0.87906, 2.70),
    vec4(0.47912, 0.11164, 0.87062, 3.70),
    vec4(-0.34485, -0.44510, 0.82641, 1.00),
    vec4(-0.45108, -0.33890, 0.82563, 2.60),
    vec4(-0.46049, -0.38462, 0.80001, 2.30),
    vec4(-0.45270, -0.44010, 0.77548, 2.90),
    vec4(-0.31613, -0.47286, 0.82248, 2.80),
    vec4(-0.24775, -0.56338, 0.78817, 2.30),
    vec4(-0.23056, -0.61635, 0.75296, 3.00),
    vec4(-0.20801, -0.67379, 0.70904, 3.60),
    vec4(-0.15084, -0.68506, 0.71270, 3.30),
    vec4(-0.07232, -0.68200, 0.72777, 1.90),
    vec4(-0.04135, -0.64452, 0.76347, 3.00),
    vec4(-0.05926, -0.62973, 0.77455, 2.40),
    vec4(-0.09167, -0.60321, 0.79230, 1.60),
    vec4(-0.10108, -0.60599, 0.78903, 2.70),
    vec4(-0.86455, 0.20740, -0.45776, 1.40),
    vec4(-0.84406, 0.28836, -0.45211, 3.50),
    vec4(-0.85251, 0.33939, -0.39753, 2.00),
    vec4(-0.82597, 0.39747, -0.39974, 3.40),
    vec4(-0.76381, 0.43853, -0.47358, 3.90),
    vec4(-0.76293, 0.40307, -0.50545, 3.00),
    vec4(-0.91783, 0.35053, -0.18632, 2.60),
    vec4(-0.96675, 0.25156, -0.04601, 2.10),
    vec4(-0.94477, 0.26606, -0.19136, 3.30),
    vec4(-0.44939, -0.89180, 0.05239, 0.80),
    vec4(-0.49379, -0.86331, 0.10428, 1.25),
    vec4(-0.53800, -0.83971, 0.07370, 1.60),
    vec4(-0.51765, -0.85491, 0.03416, 2.80),
    vec4(0.34398, 0.28418, -0.89494, 0.85),
    vec4(0.12863, 0.47885, -0.86843, 1.65),
    vec4(0.09102, 0.36065, -0.92825, 3.00),
    vec4(0.36676, 0.32854, -0.87037, 3.50),
    vec4(0.40775, 0.26942, -0.87244, 3.60),
    vec4(0.39200, 0.30137, -0.86920, 3.80),
    vec4(0.49883, 0.40833, -0.76448, 2.90),
    vec4(0.49334, 0.40753, -0.76846, 3.60),
    vec4(0.50743, 0.40849, -0.75871, 3.70),
    vec4(0.50342, 0.41263, -0.75915, 3.90),
    vec4(0.50342, 0.40594, -0.76275, 4.20),
    vec4(0.50501, 0.41422, -0.75723, 4.30),
    vec4(-0.34060, 0.52829, -0.77775, 1.60),
    vec4(-0.39144, 0.46993, -0.79116, 1.15),
    vec4(-0.15709, 0.28234, -0.94636, 1.90),
    vec4(-0.17236, 0.42467, -0.88879, 3.00),
    vec4(-0.09215, 0.38284, -0.91920, 2.90),
    vec4(-0.31754, 0.37428, -0.87125, 3.50),
    vec4(-0.18725, -0.28769, -0.93924, -1.46),
    vec4(-0.22127, -0.48435, -0.84643, 1.50),
    vec4(-0.26340, -0.44448, -0.85619, 1.80),
    vec4(-0.09407, -0.30835, -0.94661, 2.00),
    vec4(-0.31288, -0.48938, -0.81401, 2.40),
    vec4(-0.06334, -0.79547, -0.60267, -0.70),
    vec4(-0.78371, 0.32854, 0.52713, -0.05),
    vec4(0.13046, 0.71934, -0.68230, 0.08),
    vec4(-0.41811, 0.09098, -0.90383, 0.34),
    vec4(0.49269, -0.84094, -0.22375, 0.46),
    vec4(-0.91407, -0.19355, 0.35638, 1.00),
    vec4(0.83730, -0.49425, 0.23378, 1.16),
    vec4(-0.37380, -0.87326, 0.31255, -0.27),
    vec4(-0.42400, -0.86924, 0.25426, 0.60));
const vec3 COLORI[N_STELLE] = vec3[](
    vec3(1.00, 0.78, 0.52),
    vec3(0.92, 0.95, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(1.00, 0.95, 0.80),
    vec3(0.92, 0.95, 1.00),
    vec3(1.00, 0.95, 0.80),
    vec3(0.92, 0.95, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(1.00, 0.78, 0.52),
    vec3(1.00, 0.95, 0.80),
    vec3(1.00, 0.78, 0.52),
    vec3(0.70, 0.80, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(1.00, 0.55, 0.40),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(1.00, 0.95, 0.80),
    vec3(1.00, 0.78, 0.52),
    vec3(0.92, 0.95, 1.00),
    vec3(1.00, 0.78, 0.52),
    vec3(0.92, 0.95, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(1.00, 0.55, 0.40),
    vec3(0.92, 0.95, 1.00),
    vec3(1.00, 0.78, 0.52),
    vec3(1.00, 0.95, 0.80),
    vec3(1.00, 0.55, 0.40),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(1.00, 0.78, 0.52),
    vec3(0.70, 0.80, 1.00),
    vec3(1.00, 0.78, 0.52),
    vec3(0.92, 0.95, 1.00),
    vec3(1.00, 0.95, 0.80),
    vec3(1.00, 0.95, 0.80),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(1.00, 0.78, 0.52),
    vec3(0.92, 0.95, 1.00),
    vec3(1.00, 0.78, 0.52),
    vec3(1.00, 0.95, 0.80),
    vec3(0.92, 0.95, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(1.00, 0.55, 0.40),
    vec3(0.70, 0.80, 1.00),
    vec3(1.00, 0.78, 0.52),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(1.00, 0.78, 0.52),
    vec3(1.00, 0.78, 0.52),
    vec3(1.00, 0.78, 0.52),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(1.00, 0.78, 0.52),
    vec3(0.92, 0.95, 1.00),
    vec3(1.00, 0.95, 0.80),
    vec3(1.00, 0.55, 0.40),
    vec3(0.92, 0.95, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(1.00, 0.95, 0.80),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(1.00, 0.78, 0.52),
    vec3(1.00, 0.95, 0.80),
    vec3(0.92, 0.95, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.70, 0.80, 1.00),
    vec3(0.92, 0.95, 1.00),
    vec3(1.00, 0.95, 0.80),
    vec3(0.70, 0.80, 1.00));
const int N_LINEE = 76;
const ivec2 LINEE[N_LINEE] = ivec2[](
    ivec2(0, 1), ivec2(1, 2), ivec2(2, 3), ivec2(3, 0), ivec2(3, 4), ivec2(4, 5), ivec2(5, 6), ivec2(7, 8), ivec2(8, 9), ivec2(9, 10), ivec2(10, 11), ivec2(11, 12), ivec2(12, 13), ivec2(13, 10), ivec2(14, 15), ivec2(15, 16), ivec2(16, 17), ivec2(17, 18), ivec2(26, 19), ivec2(26, 21), ivec2(19, 23), ivec2(21, 25), ivec2(23, 24), ivec2(24, 25), ivec2(23, 22), ivec2(25, 20), ivec2(22, 20), ivec2(27, 28), ivec2(28, 31), ivec2(28, 29), ivec2(28, 30), ivec2(32, 33), ivec2(33, 34), ivec2(34, 35), ivec2(35, 36), ivec2(36, 33), ivec2(38, 37), ivec2(37, 39), ivec2(41, 42), ivec2(42, 43), ivec2(42, 40), ivec2(40, 44), ivec2(44, 45), ivec2(45, 46), ivec2(46, 47), ivec2(47, 48), ivec2(48, 49), ivec2(49, 50), ivec2(50, 51), ivec2(51, 52), ivec2(52, 53), ivec2(54, 55), ivec2(55, 56), ivec2(56, 57), ivec2(57, 58), ivec2(58, 59), ivec2(56, 60), ivec2(60, 61), ivec2(61, 62), ivec2(62, 54), ivec2(65, 63), ivec2(64, 66), ivec2(69, 67), ivec2(67, 71), ivec2(71, 72), ivec2(72, 70), ivec2(70, 68), ivec2(79, 82), ivec2(82, 83), ivec2(80, 84), ivec2(84, 81), ivec2(79, 80), ivec2(88, 85), ivec2(85, 87), ivec2(87, 86), ivec2(87, 89));
const int N_NEBULOSE = 8;
const vec4 NEBULOSE[N_NEBULOSE] = vec4[](vec4(0.10709, -0.09411, -0.98979, 0.1222), vec4(-0.47497, -0.86515, -0.16100, 0.1571), vec4(0.01510, -0.41310, 0.91056, 0.1047), vec4(0.50386, 0.69842, 0.50827, 0.1396), vec4(0.50050, 0.40833, -0.76339, 0.0698), vec4(-0.70773, 0.64279, 0.29315, 0.2793), vec4(0.96146, -0.17365, 0.21315, 0.3142), vec4(-0.49240, -0.64279, -0.58682, 0.2443));
const int NEB_COLORE[N_NEBULOSE] = int[](0, 0, 0, 1, 2, 1, 2, 1);
const int N_GALASSIE = 3;
const vec4 GALASSIE[N_GALASSIE] = vec4[](vec4(0.73860, 0.65961, -0.13923, 0.0559), vec4(0.05474, -0.93819, -0.34176, 0.0960), vec4(0.28744, -0.95543, -0.06729, 0.0524));
const float GAL_TILT[N_GALASSIE] = float[](0.42, 0.00, 0.00);
const vec3 POLO_GAL = vec3(-0.86769, 0.45601, 0.19793);
const vec3 CENTRO_GAL = vec3(-0.05495, -0.48389, 0.87340);

// ---------------------------------------------------------------- rumore
float hash13(vec3 p) {
    p = fract(p * 0.1031);
    p += dot(p, p.zyx + 31.32);
    return fract((p.x + p.y) * p.z);
}
vec3 hash33(vec3 p) {
    p = fract(p * vec3(0.1031, 0.1030, 0.0973));
    p += dot(p, p.yxz + 33.33);
    return fract((p.xxy + p.yxx) * p.zyx);
}
float noise3(vec3 p) {
    vec3 i = floor(p);
    vec3 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float n000 = hash13(i), n100 = hash13(i + vec3(1, 0, 0)), n010 = hash13(i + vec3(0, 1, 0)), n110 = hash13(i + vec3(1, 1, 0));
    float n001 = hash13(i + vec3(0, 0, 1)), n101 = hash13(i + vec3(1, 0, 1)), n011 = hash13(i + vec3(0, 1, 1)), n111 = hash13(i + vec3(1, 1, 1));
    return mix(mix(mix(n000, n100, f.x), mix(n010, n110, f.x), f.y), mix(mix(n001, n101, f.x), mix(n011, n111, f.x), f.y), f.z);
}
float fbm(vec3 p, int oct) {
    float s = 0.0, a = 0.5;
    for (int i = 0; i < 7; i++) {
        if (i >= oct) break;
        s += a * noise3(p);
        p = p * 2.03 + vec3(1.7, 9.2, 3.1);
        a *= 0.5;
    }
    return s;
}

// ---------------------------------------------------------------- parametri (end_sky.png)
vec4 par(int x, int y) {
    return texelFetch(Sampler0, ivec2(x, y), 0);
}
vec3 dirFrom(float elevDeg, float azDeg) {
    float e = radians(elevDeg), a = radians(azDeg);
    return vec3(cos(e) * sin(a), sin(e), -cos(e) * cos(a));
}

// ---------------------------------------------------------------- stelle
vec3 temperatura(float t) {
    // da rossa (0) a azzurra (1), passando per arancio, gialla e bianca
    vec3 c = mix(vec3(1.0, 0.55, 0.38), vec3(1.0, 0.82, 0.58), smoothstep(0.0, 0.3, t));
    c = mix(c, vec3(1.0, 0.97, 0.90), smoothstep(0.3, 0.6, t));
    return mix(c, vec3(0.68, 0.80, 1.0), smoothstep(0.65, 1.0, t));
}

vec3 campoStelle(vec3 d, float scala, float soglia, float px, float densitaVia) {
    vec3 p = d * scala;
    vec3 cella = floor(p);
    vec3 h = hash33(cella);
    float h2 = hash13(cella + 17.0);
    if (h2 > soglia * densitaVia) return vec3(0.0);
    vec3 centro = normalize(cella + 0.25 + h * 0.5) * scala;
    float dist = length(p - centro) / scala;
    float lum = pow(hash13(cella + 3.1), 6.0) * 2.4 + 0.08;
    float sigma = max(px * 0.85, 0.00035 + lum * 0.00045);
    float k = exp(-dist * dist / (2.0 * sigma * sigma));
    // energia costante: le stelle piccole di un pixel non spariscono
    k *= min(1.0, (0.00035 + lum * 0.00045) / sigma) * 1.6;
    return temperatura(hash13(cella + 7.7)) * lum * k;
}

// ---------------------------------------------------------------- Via Lattea
vec3 viaLattea(vec3 d, vec3 tinta, out float densita) {
    vec3 n = POLO_GAL;
    vec3 c = normalize(CENTRO_GAL - n * dot(CENTRO_GAL, n));
    vec3 b = cross(n, c);
    float lat = asin(clamp(dot(d, n), -1.0, 1.0));
    float lon = atan(dot(d, b), dot(d, c));
    float larghezza = 0.13 + 0.05 * sin(lon * 2.0 + 0.7);
    float banda = exp(-lat * lat / (2.0 * larghezza * larghezza));
    float nucleo = exp(-(lon * lon) / 0.55) * exp(-lat * lat / 0.035);
    float nuvole = fbm(d * 7.0, 5);
    float fine = fbm(d * 26.0, 4);
    float polveri = smoothstep(0.42, 0.75, fbm(d * 11.0 + 4.0, 5)) * exp(-lat * lat / (2.0 * 0.05 * 0.05));
    float l = banda * (0.35 + 0.65 * nuvole) * (0.7 + 0.5 * fine) + nucleo * 1.4;
    l *= 1.0 - 0.85 * polveri;
    densita = banda + nucleo;
    vec3 caldo = vec3(1.0, 0.80, 0.60), freddo = vec3(0.70, 0.78, 1.0);
    vec3 col = mix(freddo, caldo, clamp(nucleo * 2.0 + 0.25 * (1.0 - abs(lon) / PI), 0.0, 1.0));
    return col * tinta * l * 0.16;
}

// ---------------------------------------------------------------- nebulose e galassie
vec3 tangente(vec3 n) {
    return normalize(cross(abs(n.y) < 0.95 ? vec3(0, 1, 0) : vec3(1, 0, 0), n));
}

vec3 nebulose(vec3 d) {
    vec3 out_ = vec3(0.0);
    for (int i = 0; i < N_NEBULOSE; i++) {
        vec3 c = NEBULOSE[i].xyz;
        float r = NEBULOSE[i].w;
        float cosA = dot(d, c);
        if (cosA < cos(r * 1.6)) continue;
        vec3 t = tangente(c), b = cross(c, t);
        vec2 q = vec2(dot(d, t), dot(d, b)) / r;
        vec3 w = vec3(q * 2.2, float(i) * 7.3);
        vec3 warp = vec3(fbm(w + 1.3, 4), fbm(w + 8.1, 4), 0.0) * 1.6;
        float f = fbm(w + warp, 6);
        float forma = smoothstep(1.25, 0.15, length(q) + (f - 0.5) * 0.9);
        float filamenti = pow(clamp(f * 1.35 - 0.2, 0.0, 1.0), 2.0);
        float polvere = smoothstep(0.55, 0.8, fbm(w * 1.7 + 3.0, 5));
        vec3 colore = par(2 + NEB_COLORE[i], 1).rgb;
        vec3 secondo = mix(colore, vec3(1.0, 0.9, 0.95), 0.35);
        out_ += mix(colore, secondo, f) * forma * filamenti * (1.0 - 0.7 * polvere) * 0.55;
    }
    return out_;
}

vec3 galassie(vec3 d, float px) {
    vec3 out_ = vec3(0.0);
    for (int i = 0; i < N_GALASSIE; i++) {
        vec3 c = GALASSIE[i].xyz;
        float r = GALASSIE[i].w;
        if (dot(d, c) < cos(r * 1.5)) continue;
        vec3 t = tangente(c), b = cross(c, t);
        vec2 q = vec2(dot(d, t), dot(d, b)) / r;
        float tilt = GAL_TILT[i];
        if (tilt > 0.0) {
            // spirale vista di sbieco (come Andromeda)
            float ang = 0.6;
            q = mat2(cos(ang), -sin(ang), sin(ang), cos(ang)) * q;
            q.y /= tilt;
            float rr = length(q);
            float th = atan(q.y, q.x);
            float bracci = 0.5 + 0.5 * sin(th * 2.0 - log(rr + 0.02) * 5.0);
            float disco = exp(-rr * 3.2) * (0.45 + 0.55 * bracci);
            float nucleo = exp(-rr * rr * 60.0);
            out_ += (vec3(0.75, 0.80, 1.0) * disco * 0.35 + vec3(1.0, 0.88, 0.7) * nucleo * 1.2) * 0.6;
        } else {
            // nube irregolare (Magellano)
            float f = fbm(vec3(q * 3.0, float(i)), 5);
            float forma = smoothstep(1.0, 0.0, length(q) + (f - 0.5) * 0.8);
            out_ += vec3(0.85, 0.85, 1.0) * forma * f * 0.22;
        }
    }
    return out_;
}

// ---------------------------------------------------------------- costellazioni
vec3 costellazioni(vec3 d, float px, vec4 linee) {
    vec3 out_ = vec3(0.0);
    for (int i = 0; i < N_STELLE; i++) {
        vec3 s = STELLE[i].xyz;
        float dd = length(d - s);
        if (dd > 0.03) continue;
        float mag = STELLE[i].w;
        float lum = pow(2.512, -mag) * 1.3 + 0.12;
        float sigma = max(px * 0.9, 0.0005 + 0.00035 * clamp(lum, 0.0, 6.0));
        float k = exp(-dd * dd / (2.0 * sigma * sigma));
        float alone = exp(-dd * 140.0) * 0.05 * lum;
        out_ += COLORI[i] * (lum * k * 1.6 + alone);
    }
    if (linee.a > 0.0) {
        float acc = 0.0;
        for (int i = 0; i < N_LINEE; i++) {
            vec3 a = STELLE[LINEE[i].x].xyz;
            vec3 b = STELLE[LINEE[i].y].xyz;
            vec3 n = normalize(cross(a, b));
            float off = abs(dot(d, n));
            if (off > 0.004) continue;
            if (dot(cross(a, d), n) < 0.0 || dot(cross(d, b), n) < 0.0) continue;
            float vicino = min(length(d - a), length(d - b));
            float spessore = max(px * 0.75, 0.0006);
            float l = smoothstep(spessore * 1.6, spessore * 0.4, off) * smoothstep(0.006, 0.014, vicino);
            acc = max(acc, l);
        }
        out_ += linee.rgb * acc * linee.a * 0.6;
    }
    return out_;
}

// ---------------------------------------------------------------- pianeta
// ritorna il colore del pianeta (e copertura in .a) visto nella direzione d
vec4 pianeta(vec3 d, vec3 sole, float px, out float alone) {
    alone = 0.0;
    vec4 g = par(7, 0);
    if (g.a < 0.5) return vec4(0.0);
    float raggio = radians(g.r * 90.0);
    vec3 c = dirFrom(g.g * 180.0 - 90.0, g.b * 360.0);
    float cosA = dot(d, c);
    float ang = acos(clamp(cosA, -1.0, 1.0));
    vec3 atm = par(5, 0).rgb;
    float rs = sin(raggio);
    float giorno = 0.0;
    // alone dell'atmosfera fuori dal disco (piu' forte dalla parte del sole)
    float fuori = ang - raggio;
    if (fuori > 0.0) {
        vec3 versoBordo = normalize(d - c * cosA);
        float luce = clamp(dot(versoBordo, sole) * 0.8 + 0.35, 0.0, 1.0);
        alone = exp(-fuori / (raggio * 0.035)) * luce;
        return vec4(atm * alone * 1.1, 0.0);
    }
    // punto sulla sfera (distanza 1, raggio rs)
    float b = cosA;
    float disc = b * b - (1.0 - rs * rs);
    float t = b - sqrt(max(disc, 0.0));
    vec3 n = normalize(d * t - c);
    // rotazione lenta del pianeta (asse quasi verticale)
    float rot = GameTime * 6.2831 * (par(1, 1).a * 4.0) * 3.0;
    mat3 asse = mat3(cos(rot), 0.0, sin(rot), 0.0, 1.0, 0.0, -sin(rot), 0.0, cos(rot));
    vec3 p = asse * n;
    float lat = abs(p.y);
    float cont = fbm(p * 2.2 + 11.0, 7);
    float terra = smoothstep(0.50, 0.53, cont);
    float alto = smoothstep(0.58, 0.70, cont);
    float secco = smoothstep(0.45, 0.75, fbm(p * 3.5 + 2.0, 5)) * (1.0 - smoothstep(0.55, 0.8, lat));
    vec3 oceano = par(1, 0).rgb * (0.75 + 0.35 * fbm(p * 9.0, 3));
    vec3 verde = par(2, 0).rgb * (0.8 + 0.4 * fbm(p * 18.0, 4));
    vec3 sabbia = par(3, 0).rgb * (0.85 + 0.3 * fbm(p * 14.0, 3));
    vec3 suolo = mix(verde, sabbia, secco);
    suolo = mix(suolo, suolo * 0.75 + 0.12, alto);
    vec3 col = mix(oceano, suolo, terra);
    vec4 gh = par(4, 0);
    float calotta = smoothstep(0.80, 0.86, lat + (fbm(p * 6.0, 4) - 0.5) * 0.12);
    col = mix(col, gh.rgb, calotta);
    // nuvole: si muovono piu' veloci della superficie
    float rotN = rot * 1.35 + GameTime * 2.0;
    mat3 asseN = mat3(cos(rotN), 0.0, sin(rotN), 0.0, 1.0, 0.0, -sin(rotN), 0.0, cos(rotN));
    vec3 pn = asseN * n;
    float nuv = smoothstep(0.52 - gh.a * 0.25, 0.78, fbm(pn * 3.0 + vec3(0.0, fbm(pn * 2.0, 3) * 1.5, 0.0), 6));
    // luce: terminatore morbido, crepuscolo arancio, riflesso del sole sugli oceani
    float nl = dot(n, sole);
    float diff = smoothstep(-0.08, 0.35, nl);
    vec3 crepuscolo = vec3(1.0, 0.55, 0.3) * exp(-nl * nl / 0.006) * 0.4;
    vec3 h = normalize(sole - d);
    float spec = pow(max(dot(n, h), 0.0), 60.0) * (1.0 - terra) * (1.0 - nuv) * 0.9;
    vec3 lit = col * diff + crepuscolo * diff * 0.0 + crepuscolo + spec * vec3(1.0, 0.95, 0.85);
    lit = mix(lit, vec3(0.95) * (diff + crepuscolo.r * 0.6), nuv * 0.92);
    // lato in ombra: luci delle citta' sulla terra, senza nuvole
    float notte = 1.0 - smoothstep(-0.12, 0.05, nl);
    float citta = pow(clamp(fbm(p * 40.0, 3) * 1.7 - 0.85, 0.0, 1.0), 2.0) * terra * (1.0 - secco * 0.6) * (1.0 - calotta);
    lit += par(6, 0).rgb * citta * notte * (1.0 - nuv) * 1.4;
    lit += col * 0.018;
    // atmosfera sul bordo (Rayleigh)
    float bordo = 1.0 - clamp(dot(n, -d), 0.0, 1.0);
    float fres = pow(bordo, 3.0);
    lit += atm * fres * (0.25 + 0.9 * clamp(nl + 0.3, 0.0, 1.0));
    lit = mix(lit, atm * (diff * 0.8 + 0.05), pow(bordo, 6.0) * 0.6);
    // bordo antialias
    float copertura = smoothstep(0.0, px * 1.5, raggio - ang);
    return vec4(lit, copertura);
}

// ---------------------------------------------------------------- tutto lo spazio
vec3 spazio(vec3 d, float px) {
    vec4 sp = par(1, 1);
    vec3 sole = dirFrom(sp.r * 180.0 - 90.0, sp.g * 360.0);
    vec4 fondo = par(6, 1);
    vec3 col = fondo.rgb * (0.6 + 0.4 * fbm(d * 3.0, 3));
    float densitaVia;
    col += viaLattea(d, par(5, 1).rgb, densitaVia);
    col += nebulose(d);
    col += galassie(d, px);
    float dens = (0.6 + densitaVia * 2.4) * (fondo.a * 2.0);
    col += campoStelle(d, 55.0, 0.05, px, dens) * 1.1;
    col += campoStelle(d, 140.0, 0.018, px, dens) * 0.65;
    col += campoStelle(d, 380.0, 0.005, px, dens) * 0.35;
    col += costellazioni(d, px, par(7, 1));
    // la stella vicina: disco, corona e alone
    float ds = acos(clamp(dot(d, sole), -1.0, 1.0));
    float gs = 0.0065 * (sp.b * 4.0 + 0.05);
    vec3 sc = par(0, 1).rgb;
    col += sc * smoothstep(gs + px, gs - px, ds) * 6.0;
    col += sc * (exp(-ds / (gs * 2.5)) * 0.9 + exp(-ds / (gs * 14.0)) * 0.22 + exp(-ds / 0.6) * 0.06);
    // una luna lontana (parametri 2,2 e 3,2), illuminata dalla stessa stella
    vec4 lp = par(3, 2);
    if (lp.a > 0.5) {
        float lr = radians(lp.r * 30.0);
        vec3 lc = dirFrom(lp.g * 180.0 - 90.0, lp.b * 360.0);
        float la = acos(clamp(dot(d, lc), -1.0, 1.0));
        if (la < lr * 1.6) {
            float rs = sin(lr);
            float bb = dot(d, lc);
            float disc = bb * bb - (1.0 - rs * rs);
            if (disc > 0.0) {
                vec3 n = normalize(d * (bb - sqrt(disc)) - lc);
                float crateri = fbm(n * 9.0 + 5.0, 5);
                float mari = smoothstep(0.45, 0.62, fbm(n * 2.5 + 1.0, 4));
                vec3 albedo = par(2, 2).rgb * (0.75 + 0.35 * crateri) * (1.0 - 0.35 * mari);
                float luce = smoothstep(-0.05, 0.25, dot(n, sole));
                float cop = smoothstep(0.0, px * 1.5, lr - la);
                col = mix(col, albedo * (luce * 1.1 + 0.015), cop);
            }
        }
    }
    // il pianeta copre tutto quello che c'e' dietro
    float alone;
    vec4 pl = pianeta(d, sole, px, alone);
    col = mix(col + pl.rgb * (1.0 - pl.a), pl.rgb, pl.a);
    return col;
}

vec3 tonemap(vec3 c) {
    c = c / (1.0 + c * 0.6);
    return pow(c, vec3(0.92));
}

void main() {
    ivec2 sz = textureSize(Sampler0, 0);
    if (sz == ivec2(8, 4)) {
        vec4 m = par(0, 0);
        if (abs(m.r * 255.0 - 77.0) < 0.5 && abs(m.g * 255.0 - 82.0) < 0.5 && abs(m.b * 255.0 - 67.0) < 0.5) {
            vec3 d = normalize(skyPos);
            float px = max(length(fwidth(d)), 0.0002);
            fragColor = vec4(tonemap(spazio(d, px)), 1.0);
            return;
        }
    }
    vec4 color = texture(Sampler0, texCoord0) * vertexColor;
    if (color.a == 0.0) {
        discard;
    }
    fragColor = color * ColorModulator;
}
