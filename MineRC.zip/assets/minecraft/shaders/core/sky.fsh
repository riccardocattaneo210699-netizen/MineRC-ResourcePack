#version 330
#extension GL_ARB_separate_shader_objects : require

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>

// MineRC: cielo con la sfumatura dell'atmosfera (resourcepack/cielo.py)
layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec3 skyPos;

layout(location = 0) out vec4 fragColor;

float luma(vec3 c) { return dot(c, vec3(0.2126, 0.7152, 0.0722)); }

void main() {
    vec3 d = normalize(skyPos);
    vec3 cielo = ColorModulator.rgb;
    vec3 nebbia = FogColor.rgb;
    float e = d.y;
    float giorno = smoothstep(0.03, 0.35, luma(cielo));
    // zenit piu' saturo e profondo, orizzonte piu' chiaro (scattering)
    vec3 zenit = mix(cielo * vec3(0.78, 0.86, 1.0), cielo, 0.35);
    zenit = mix(vec3(luma(zenit)), zenit, 1.18);
    vec3 orizzonte = mix(nebbia, cielo, 0.25) * 1.06 + vec3(0.02, 0.025, 0.03) * giorno;
    float h = pow(1.0 - clamp(e, 0.0, 1.0), 3.2);
    vec3 col = mix(zenit, orizzonte, h);
    // foschia bassa appena sopra l'orizzonte
    col = mix(col, nebbia, exp(-max(e, 0.0) * 28.0) * 0.55);
    // di notte un blu scurissimo, mai nero pieno
    col = max(col, vec3(0.006, 0.008, 0.016) * (1.0 - giorno));
    vec4 c = vec4(clamp(col, 0.0, 1.0), ColorModulator.a);
    fragColor = apply_fog(c, sphericalVertexDistance, cylindricalVertexDistance, 0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
}
